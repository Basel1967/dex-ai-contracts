# ADR-NNN: Title

Status: Proposed

## Context
## Decision
## Consequences
## Normative boundaries
## Approvals
